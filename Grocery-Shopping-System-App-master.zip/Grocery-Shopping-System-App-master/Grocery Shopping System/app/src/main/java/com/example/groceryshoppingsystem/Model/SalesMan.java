package com.example.groceryshoppingsystem.Model;

public class SalesMan {
    public String  salary , img;

    public SalesMan(String salary, String img) {
        this.salary = salary;
        this.img = img;
    }


}
