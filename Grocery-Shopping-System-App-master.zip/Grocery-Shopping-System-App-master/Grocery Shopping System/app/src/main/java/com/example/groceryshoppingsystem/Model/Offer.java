package com.example.groceryshoppingsystem.Model;

public class Offer {
    public String describtion , img;

    public Offer(String describtion, String img) {

        this.describtion = describtion;
        this.img = img;
    }
}
