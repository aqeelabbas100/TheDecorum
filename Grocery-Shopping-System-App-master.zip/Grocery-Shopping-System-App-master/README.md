# Grocery-Shopping-System-App
Full android Grocery Shopping System App. It consist of Admin and users: (Using online Firebase Database) Admin can login to the system. He also can to Add, Edit, Delete an Existence category/s  or create new category (Category name, Category cost, available Category amount, Expiry date)  Users can to register or login to the system  the system shows the existence categories (fruits, meats, Vegetables, etc...) the user can search about product and know product info (cost, available amount, Expiry date) the user also can to make an order by giving the system (Destination, product name, product amount) the delivery task is deliver this product to the user in selected time


#Some images


![1](https://user-images.githubusercontent.com/52586356/106370080-96530c00-635f-11eb-8501-b4766b2da5e9.png)



![2](https://user-images.githubusercontent.com/52586356/106370085-9fdc7400-635f-11eb-8247-b34ae9d6400a.png)



![3](https://user-images.githubusercontent.com/52586356/106370090-a834af00-635f-11eb-940f-b05f451867ba.png)



![4](https://user-images.githubusercontent.com/52586356/106370098-aff45380-635f-11eb-9935-3f7ef8a864ea.png)



![5](https://user-images.githubusercontent.com/52586356/106370101-b5519e00-635f-11eb-8a67-8a7bb6a45024.png)



![6](https://user-images.githubusercontent.com/52586356/106370105-bbe01580-635f-11eb-869b-1fb6c99913c1.png)



![7](https://user-images.githubusercontent.com/52586356/106370111-c1d5f680-635f-11eb-821e-d923f85593c5.png)



![8](https://user-images.githubusercontent.com/52586356/106370118-c8646e00-635f-11eb-8d18-dc95c33bb977.png)



![9](https://user-images.githubusercontent.com/52586356/106370125-d0241280-635f-11eb-846f-065f4d1f8fc0.png)



![10](https://user-images.githubusercontent.com/52586356/106370126-d74b2080-635f-11eb-9e62-66cb432b478e.png)



![11](https://user-images.githubusercontent.com/52586356/106370128-dca86b00-635f-11eb-991d-578c6dc0c973.png)



![12](https://user-images.githubusercontent.com/52586356/106370131-e336e280-635f-11eb-86cb-71df1b25b2dd.png)



![13](https://user-images.githubusercontent.com/52586356/106370132-e9c55a00-635f-11eb-9d69-591e389ecc82.png)



![14](https://user-images.githubusercontent.com/52586356/106370135-efbb3b00-635f-11eb-8b77-bd50714394aa.png)



![15](https://user-images.githubusercontent.com/52586356/106370137-f47fef00-635f-11eb-8c22-2de5fb6b9810.png)



![16](https://user-images.githubusercontent.com/52586356/106370138-fb0e6680-635f-11eb-9c62-efae45d33e8b.png)



![17](https://user-images.githubusercontent.com/52586356/106370141-01044780-6360-11eb-85f2-928ede8b7046.png)



![18](https://user-images.githubusercontent.com/52586356/106370148-06619200-6360-11eb-9429-5dc831dcef6f.png)



![19](https://user-images.githubusercontent.com/52586356/106370152-0c577300-6360-11eb-8a9d-d7b74f48733a.png)



![20](https://user-images.githubusercontent.com/52586356/106370158-11b4bd80-6360-11eb-9b91-c3fb70165bb4.png)



![21](https://user-images.githubusercontent.com/52586356/106370160-17aa9e80-6360-11eb-86bc-f4a1cd08679e.png)


 
#***** tasks work *****

Login Activity (Amr)

Register Activity (Osama)

Splash Screen (Ziad)

Admin Activity (Kareem)

Reset Passowrd (Ziad)

Create Products & Offers & SalesMen Fragment (Kareem)

Main Activity (Amr & Osama)

Main Navigation View (Amr)

User Profile Activity (Kareem)

ADD, Edit, Delete (Products/SalesMen/Offers) (Ziad)

All Categories Activity (Kareem)

Product Info Activity (Kareem)

Favorite Activity (Amr)

Offline Capability(Loading data in case offline internet) (Kareem)

Products & Offers & SalesMen Fragment Methods (Ziad)

Cart & Orders (Osama)

Products Offers (Kareem)

Cart Icon Badge Feature (Number Of Products in cart Icon) (Kareem)

Admin Animation (Ziad)

Login & Register Animation (Amr)

Category Animation (Kareem)

QR Code Generator (Ziad)

QR Code Scanner (Kareem)

