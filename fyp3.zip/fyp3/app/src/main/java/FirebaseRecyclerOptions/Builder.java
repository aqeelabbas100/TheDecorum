package FirebaseRecyclerOptions;

public class Builder<T> {
}
