package com.example.fyp;

public class Product {
    public String name;
    public String size;
    public String imageurl;
    public String path;
    public String extension;


    public Product(String name,String size,String imageurl){
        this.name = name;
        this.size = size;
        this.imageurl = imageurl;
        this.path = path;
        this.extension = extension;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getModel() {
        return path;
    }

    public void setModel(String model) {
        this.path = model;
    }

    public Product(){}

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }
}
