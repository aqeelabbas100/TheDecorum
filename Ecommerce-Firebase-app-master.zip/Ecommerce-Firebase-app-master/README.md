# Ecommerce-Firebase-app
It is an ecommerce app made in for retail shops and their surrounding customers. After this app no one will hear like "sorry mam/sir, product is not available". In the backend it will get from more far store. This will give business to smaller business owner rather then ecommer like amazon and flipkart. This idea was brainstormed by me and with the help of my two team members we made this project. Technologies used in this project are android with java and database in firebase which is own by google.


# Ecommerce-Firebase-app in technical language
App specifically targeting smaller stores rather than giving business top tech giants like amazon and flipkart.
Its algorithm is specifically designed to search product on distance between home and stores selling that particular products.

Algorithm is on server which is not released for public use. As this project is 80% completed. 

Security and A/B testing are still left. Its just a prototype build in android as our full product is in FLUTTER as we cant miss ios usesr.

This project is just a prototype of the full product and it uses technologies like:
  1)Android
  2)Java
  3)Firebase
  4)Cloud Function on Google
  5)Javascript to write cloud functions
  
 Material Design is used to design app interface.
Some of the screenshots given below.
![Screenshot_20190723_142603](https://user-images.githubusercontent.com/29975909/61706703-5ffa0100-ad66-11e9-9c42-387665a870e4.png)
![Screenshot_20190723_142630](https://user-images.githubusercontent.com/29975909/61706704-5ffa0100-ad66-11e9-8958-9688ac04760f.png)
![Screenshot_20190723_142705](https://user-images.githubusercontent.com/29975909/61706705-5ffa0100-ad66-11e9-9b10-751afa549d86.png)
![Screenshot_20190723_142728](https://user-images.githubusercontent.com/29975909/61706706-60929780-ad66-11e9-89e1-57886adbb037.png)
![Screenshot_20190723_142755](https://user-images.githubusercontent.com/29975909/61706707-60929780-ad66-11e9-8434-f458bef15cd6.png)
![Screenshot_20190723_142915](https://user-images.githubusercontent.com/29975909/61706709-60929780-ad66-11e9-934f-680bb45d5623.png)
![Screenshot_20190723_142942](https://user-images.githubusercontent.com/29975909/61706710-612b2e00-ad66-11e9-8d92-bf70d4dcb28a.png)
![Screenshot_20190723_143037](https://user-images.githubusercontent.com/29975909/61706711-612b2e00-ad66-11e9-91a6-e2848d3ec1b2.png)
![Screenshot_20190723_143104](https://user-images.githubusercontent.com/29975909/61706712-612b2e00-ad66-11e9-8c01-6b9e388d700d.png)
